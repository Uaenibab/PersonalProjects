#/usr/bin/env python
APP_HOST = 'localhost'
APP_PORT =  80
APP_DEBUG = True
